<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContaSocial extends Model
{
    

    CONST TIPO_PERFIL = 1;
    CONST TIPO_PAGINA = 2;
  

    protected $fillable = [

        'nome',
      
       
    ];
    protected $guarded = [
        'id',
        'provedor',
        'senha',
        'provedor_id',
        'token',
        'token_senha',
        'situacao',
        'user_id',
        'grupo_conta_id',
    ];


    public function conta(){
    return $this::belongsTo('\App\ContaSocial', 'conta_id');
    }

    public function grupo(){
        return $this::belongsTo('\App\GrupoConta', 'grupo_id');
        }

public function getTipos(){
    return [
self::TIPO_PERFIL => 'perfil',
self::TIPO_PAGINA => 'página'
    ];
}

public function getTipoTexto(){
    return $this->getTipos()[$this->tipo];
}


}
