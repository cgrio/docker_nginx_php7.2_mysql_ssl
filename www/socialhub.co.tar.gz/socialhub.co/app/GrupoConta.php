<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GrupoConta extends Model
{
    protected $fillable = [
       'nome',
       'descricao',
       'tipo',
       'situacao',
    ];

    protected $guarded = [
        'id',
        'user_id',
     ];

     public function conta(){
      return $this::belongsTo('\App\User', 'user_id');
      }


     public function contas(){
      return $this::hasMany('\App\ContaSocial', 'grupo_conta_id');
      }
}
