<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Facebook\Exceptions\FacebookSDKException;
use Facebook\Facebook;
use Illuminate\Support\Facades\Auth;

class OperacoesSociaisController extends Controller
{
    //


    private $api;
    public function __construct(Facebook $fb)
    {
        $this->middleware(function ($request, $next) use ($fb) {
            $fb->setDefaultAccessToken(Auth::user()->token);
            $this->api = $fb;
            return $next($request);
        });
    }

    public function buscarusuario(Request $request){
        
    }
    public function recuperarpaginas(Request $request){
        
    }
    public function postar(Request $request){
        
    }

    public function postarFoto(Request $request){


switch($request->get('provedor')){
    case 'facebook':
              
        try {
            $response = $this->api->post('/me/feed', [
                'message' => $request->mensagem,
                'source'    =>  $this->api->fileToUpload($request->get('imagem'))
            ])->getGraphNode()->asArray();
     
            if($response['id']){
               // post created

            }
        } catch (FacebookSDKException $e) {
            dd($e); // handle exception
        }

    break;
    case  'twitter':
        
    break;
}


  
        
    }




    public function recuperartimeline(Request $request){
        
    }
}
