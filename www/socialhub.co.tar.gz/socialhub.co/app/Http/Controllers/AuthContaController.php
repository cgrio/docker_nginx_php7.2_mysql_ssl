<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator, Redirect, Response, File;
use Socialite;
use App\User;
use App\ContaSocial;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class AuthContaController extends Controller
{
    public function redirect($provider, $grupo)
    {
        $scopes = [
            'facebook' => [
                'email',
                'user_birthday',
                'user_location',
                'user_friends',
                'user_gender',
                'user_age_range',
                'manage_pages',
                'pages_manage_cta',
                'pages_manage_instant_articles',
                'pages_show_list',
                'pages_messaging',
                'publish_pages',
                'business_management',
                'email',
                'groups_access_member_info',
                'publish_to_groups',
                'user_age_range',
                'user_birthday',
                'user_friends',
                'user_gender',
                'user_hometown',
                'user_likes',
                'user_link',
                'user_location',
                'user_photos',
                'user_posts',
                'user_videos'
            ],
            'linkedin' => [
                'w_member_social',
                'r_liteprofile',
                'r_emailaddress'
            ]
        ];


        $fields = [
            'facebook' => [
                'name', // Default
                'email', // Default
                'gender', // Default
                'birthday', // I've given permission
                'location', // I've given permission
            ],

        ];

        switch ($provider) {
            case 'facebook':
                return Socialite::driver($provider)
                    ->with(['grupo' => $grupo])
                    ->fields($fields[$provider])
                    ->scopes($scopes[$provider])
                    ->redirect();
                break;
            case 'linkedin':
                return Socialite::driver($provider)
                    ->scopes($scopes[$provider])
                    ->redirect();
                break;
            default:
                return Socialite::driver($provider)
                    ->redirect();
        }
    }
    public function callback($provider)
    {
        $url_anterior = request()->session()->previousUrl();
        $url_anterior = explode("/", $url_anterior);
        $grupo = end($url_anterior);

        $userFromSocialite = Socialite::driver($provider)->user();
        $user = $this->createConta($userFromSocialite, $provider, $grupo);
        // auth()->login($user);
        return redirect()->to('grupos/' . $grupo . '/gerenciar');
    }


    function createConta($userFromSocialite, $provider, $grupo)
    {

        $conta = ContaSocial::firstOrNew([
            'user_id' => Auth::id(),
            'provedor' => $provider,
            'provedor_id' => $userFromSocialite->id,
        ]);
        $time = Carbon::now();

        $conta->provedor = $provider;
        $conta->provedor_id = $userFromSocialite->id;
        $conta->nome = $userFromSocialite->getName();
        $conta->login = $userFromSocialite->getNickname() == null ? Str::snake($userFromSocialite->getName()) : $userFromSocialite->getNickname();
        $conta->email = $userFromSocialite->getEmail();
        $conta->tipo = ContaSocial::TIPO_PERFIL;
        $conta->token = isset($userFromSocialite->token) ? $userFromSocialite->token : null;
        $conta->token_senha = isset($userFromSocialite->tokenSecret) ? $userFromSocialite->tokenSecret : null;
        $conta->token_validade = isset($userFromSocialite->expiresIn) ? $time->copy()->addSeconds($userFromSocialite->expiresIn)->toDateTimeString() : null;
        $conta->token_atualizado = isset($userFromSocialite->refreshToken) ? $userFromSocialite->refreshToken : null;
        $conta->avatar = $userFromSocialite->getAvatar();
        $conta->user_id = Auth::id();
        $conta->grupo_conta_id = $grupo;
        $conta->save();


        return $conta;
    }
}
