<?php

namespace App\Http\Controllers;

use App\GrupoConta;
use App\ContaSocial;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class GrupoContaController extends Controller
{

      /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $grupos = Auth::user()->gruposcontas()->latest()->paginate(5);
        return view('grupos.index', compact('grupos'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('grupos/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'nome' => 'required'
        ]);

        $usuario = Auth::user();
        $usuario->gruposcontas()->create($request->all());
       // $usuario->save();
        return redirect()->route('grupos.index')->with('success', 'GrupoConta cadastrado com sucesso.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\GrupoConta  $grupo
     * @return \Illuminate\Http\Response
     */
    public function show(GrupoConta $grupo)
    {
        //
        return view('grupos.show', compact('grupo'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\GrupoConta  $grupo
     * @return \Illuminate\Http\Response
     */
    public function edit(GrupoConta $grupo)
    {
        //
        return view('grupos.edit', compact('grupo'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\GrupoConta  $grupo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, GrupoConta $grupo)
    {
        //
        $request->validate([
            'nome' => 'required'
        ]);

        $grupo->update($request->all());
        return redirect()->route('grupos.index')->with('success', 'GrupoConta editado com sucesso.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\GrupoConta  $grupo
     * @return \Illuminate\Http\Response
     */
    public function destroy(GrupoConta $grupo)
    {
        //
        $grupo->delete();
        return redirect()->route('grupos.index')->with('success', 'GrupoConta apagado com sucesso.');
    }



    /**
     * Display the specified resource.
     *
     * @param  \App\GrupoConta  $grupo
     * @return \Illuminate\Http\Response
     */
    public function gerenciar(GrupoConta $grupo)
    {
       $contas = $grupo->contas;
        return view('grupos.gerenciar', compact( 'grupo', 'contas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function adicionarConta(GrupoConta $grupo, Request $request)
    {

        //dd(array_merge($request->all(),["user_id"=>Auth::id(),"grupo_conta_id"=>$grupo->id]));
        //
        $request->validate([
            'nome' => 'required'
        ]);

        $usuario = Auth::user();

        $conta = ContaSocial::firstOrNew($request->except('_token'));
        $conta->user_id = Auth::id();
        $conta->grupo_conta_id = $grupo->id;
        $conta->save();
        return redirect('/grupos/' . $grupo->id . '/gerenciar')->with('success', 'GrupoConta cadastrado com sucesso.');
    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function removerConta(GrupoConta $grupo, ContaSocial $grupoconta, Request $request)
    {

        //
        $grupoconta->delete();

        return redirect('/grupos/' . $grupo->id . '/gerenciar')->with('success', 'GrupoConta cadastrado com sucesso.');
    }
}
