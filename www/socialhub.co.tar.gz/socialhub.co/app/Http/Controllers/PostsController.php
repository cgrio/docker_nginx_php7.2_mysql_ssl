<?php

namespace App\Http\Controllers;

use App\Posts;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $posts = Auth::user()->posts();
        return view('posts.index', compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $post = new Posts();
        return view('posts.create', compact('post'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Define o valor default para a variável que contém o nome da imagem 
        $nameFile = null;

        // Verifica se informou o arquivo e se é válido
        if ($request->hasFile('imagem') && $request->file('imagem')->isValid()) {

            // Define um aleatório para o arquivo baseado no timestamps atual
            $name = uniqid(date('HisYmd'));

            // Recupera a extensão do arquivo
            $file = $request->file('imagem');
          //  $filename = $file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();
          //  $tempPath = $file->getRealPath();
            $fileSize = $file->getSize();
            $mimeType = $file->getMimeType();
            // Define finalmente o nome
            $nameFile = Auth::id() . "_" ."{$name}.{$extension}";
 // Valid File Extensions
 $valid_extension = array("jpg","jpeg","png");

 // 2MB in Bytes
 $maxFileSize = 2097152;

 // Check file extension
 if(in_array(strtolower($extension),$valid_extension) && (stristr($mimeType,"image"))){

   // Check file size
   if($fileSize <= $maxFileSize){

      // File upload location
    //  $location = 'images';

      // Upload file
      //$file->move($location,$filename);
            // Faz o upload:
            $upload = $request->imagem->storeAs('posts', $nameFile);
            // Se tiver funcionado o arquivo foi armazenado em storage/app/public/categories/nomedinamicoarquivo.extensao

            // Verifica se NÃO deu certo o upload (Redireciona de volta)
            if (!$upload){
                return redirect()
                    ->back()
                    ->with('error', 'Falha ao fazer upload')
                    ->withInput();
             }
    }else{
        return redirect()
        ->back()
        ->with('error', 'Imagem Grande demais')
        ->withInput();
    }

}else{
        return redirect()
        ->back()
        ->with('error', 'Imagem não reconhecida tente outro arquivo')
        ->withInput();
    }
}

        $request->validate([
            'titulo' => 'required'
        ]);


        $post = Posts::firstOrNew($request->except(['_token', 'imagem']));
        $post->user_id = Auth::id();
        $post->imagem = empty($nameFile)?null:$nameFile;
        $post->save();
        return redirect('posts')->with('sucess', 'Post salvo com sucesso!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Posts  $posts
     * @return \Illuminate\Http\Response
     */
    public function show(Posts $posts)
    {
        return view('posts.show',compact($posts));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Posts  $posts
     * @return \Illuminate\Http\Response
     */
    public function edit(Posts $posts)
    {
        return view('posts.edit',compact($posts));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Posts  $posts
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Posts $posts)
    {
         //
         $request->validate([
            'titulo' => 'required'
        ]);

        $posts->update($request->all());
        return redirect()->route('posts.index')->with('success', 'Posts editado com sucesso.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Posts  $posts
     * @return \Illuminate\Http\Response
     */
    public function destroy(Posts $posts)
    {
        $posts->delete();
        return redirect()->route('posts.index')->with('success', 'Post apagado com sucesso.');
    }
}
