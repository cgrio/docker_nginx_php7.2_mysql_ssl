<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Posts extends Model
{
    //
protected $fillable = [


    'id',
    'titulo',
    'descricao',
    'mensagem',
    'email',
    'imagem',
    'link',
    'whatsapp',
    'tags',
    'marcacoes',
    'user_id',
    'situacao',
];
}
