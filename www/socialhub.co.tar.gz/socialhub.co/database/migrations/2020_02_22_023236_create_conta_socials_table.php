<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateContaSocialsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('conta_socials', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('nome');
            $table->string('provedor');
            $table->string('login')->nullable();
            $table->string('email')->nullable();
            $table->string('senha')->nullable();
            $table->integer('tipo');
            $table->string('provedor_id')->nullable();
            $table->text('token')->nullable();
            $table->text('token_senha')->nullable();
            $table->string('token_atualizado')->nullable();
            $table->date('token_validade')->nullable();
            $table->string('avatar')->nullable();
            $table->integer('situacao')->default(1);
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('grupo_conta_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('conta_socials');
    }
}
