@extends('layouts.app')
@section('content')

@include('contassociais.tabela',['contas'=>$contas])
@endsection