@if (isset($contas) && !empty($contas))
@foreach($contas as $conta)
<div class="row mb-1">
    <div class="col-3">{{$conta->nome}}</div>
    <div class="col-3">{{$conta->descricao}}</div>
    <div class="col-2">{{$conta->getTipoTexto()}}</div>
    <div class="col-2">{{$conta->provedor}}</div>

    <div class="col-2">
    <form action="{{ route('contassociais.destroy',$conta->id) }}" method="POST">
@csrf
@method('DELETE')

<button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja apagar?')">Apagar</button>
</form>
    </div>
</div>
@endforeach
@endif