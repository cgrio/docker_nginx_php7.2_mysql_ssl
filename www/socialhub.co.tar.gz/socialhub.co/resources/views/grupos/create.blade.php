@extends('layouts.app')
@section('content')
<div class="row">
    <div class="col-lg-12 px-5 py-2">
        <div class="float-left">
            <h2>Novo Grupo</h2>
        </div>
        <div class="float-right">
            <a class="btn btn-primary" href="{{ route('grupos.index') }}"> Voltar</a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 px-5 py-2">
        @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Ops!</strong> Algumas informações precisam da sua atenção.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
</div>
<div class="row">
    <div class="col-lg-12 px-5 py-2">
        <form action="{{ route('grupos.store') }}" method="POST">
            @csrf

            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Nome:</strong>
                        <input type="text" name="nome" class="form-control" placeholder="Nome">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Descrição:</strong>
                        <textarea class="form-control" style="height:150px" name="descricao" placeholder="Descrição"></textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">Enviar</button>
                </div>
            </div>

        </form>
    </div>
</div>
@endsection