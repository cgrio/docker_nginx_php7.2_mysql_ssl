@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col">
            <h1>Gerenciar Grupo</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 px-5 py-3">
            <p>
                <strong>Nome:</strong>
                {{ $grupo->nome }}
            </p>
            <p>
                <strong>Descrição:</strong>
                {{ $grupo->descricao }}
            </p>
        </div>
    </div>
    <div class="row">
        <div class="col">
        @if ($errors->any())
        <div class="alert alert-danger">
          <p>  <strong>Ops!</strong> Algumas informações precisam da sua atenção.</p>
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
        </div>
    </div>
    <div class="row">

            <div class="col">
                <a href="/auth/redirect/facebook/{{ $grupo->id }}"><i class="h3 fab fa-facebook-f"></i>Facebook</a>
                <a href="/auth/redirect/twitter/{{ $grupo->id }}"><i class="h3 fab fa-twitter-f"></i>Twitter</a>
                <a href="/auth/redirect/linkedin/{{ $grupo->id }}"><i class="h3 fab fa-linkedin-f"></i>Linkedin</a>
                <a href="/auth/redirect/instagram/{{ $grupo->id }}"><i class="h3 fab fa-instagram-f"></i>Instagram</a>
                <a href="/auth/redirect/pinterest/{{ $grupo->id }}"><i class="h3 fab fa-pinterest-f"></i>Pinterest</a>
            </div>
    </div>
    
    @include('contassociais.tabela',['contas' => $contas])
</div>


@endsection