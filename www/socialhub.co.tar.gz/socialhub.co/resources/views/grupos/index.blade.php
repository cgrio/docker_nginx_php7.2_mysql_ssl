@extends('layouts.app')
@section('content')


<div class="row">
        <div class="col-lg-12 px-5 py-3">
            <div class="float-left">
                <h2>Grupos</h2>
            </div>
            <div class="float-right">
                <a class="btn btn-success" href="{{ route('grupos.create') }}"> Novo Grupo</a>
            </div>
        </div>
    </div>


    <div class="row">
<div class="col-12 px-5 py-3">

@if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif


</div>

</div>




<div class="row">
<div class="col-12 px-5">



    <table class="table table-bordered">
        <tr>
            <th>id</th>
            <th>Nome</th>
            <th>Descrição</th>
            <th width="350px">Ações</th>
        </tr>
     @if(!empty($grupos))
        @foreach ($grupos as $grupo)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $grupo->nome }}</td>
            <td>{{ $grupo->descricao }}</td>
            <td>
                <form action="{{ route('grupos.destroy',$grupo->id) }}" method="POST">

                    <a class="btn btn-info" href="{{ route('grupos.show',$grupo->id) }}">Ver</a>

                    <a class="btn btn-primary" href="{{ route('grupos.edit',$grupo->id) }}">Editar</a>

                    @csrf
                    @method('DELETE')

                    <button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja apagar?')">Apagar</button>
                    <a class="btn btn-success" href="/grupos/{{$grupo->id}}/gerenciar">Gerenciar</a>
                </form>
            </td>
        </tr>
        @endforeach
        @endif
    </table>

    {!! $grupos->links() !!}




</div>

</div>







@endsection
