@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb  px-5 py-3">
            <div class="float-left">
                <h2> Grupo</h2>
            </div>
            <div class="float-right">
                <a class="btn btn-primary" href="{{ route('grupos.index') }}"> Voltar</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 px-5 py-3">
            <p>
                <strong>Nome:</strong>
                {{ $grupo->nome }}
</p>
      <p>
                <strong>Descrição:</strong>
                {{ $grupo->descricao }}
</p>
        </div>
    </div>
@endsection
