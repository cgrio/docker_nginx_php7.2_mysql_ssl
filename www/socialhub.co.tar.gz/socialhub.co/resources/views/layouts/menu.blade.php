
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('contassociais.index') }}">{{ __('Contas Sociais') }}</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('grupos.index') }}">{{ __('Grupos Sociais') }}</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('posts.index') }}">{{ __('Posts') }}</a>
                            </li>