@extends('layouts.app')
@section('content')
<div class="row">
    <div class="col ">

        <h1>Posts</h1>
        <a class="btn btn-info" href="{{ route('posts.create') }}">Novo</a>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 py-2 px-5">
        @if ($errors->any())
        <div class="alert alert-danger">
          <p>  <strong>Ops!</strong> Algumas informações precisam da sua atenção.</p>
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
</div>
<div class="row">
    <div class="col-lg-12 py-2 px-5">
        <form action="{{ route('posts.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Título:</strong>
                        <input type="text" name="titulo" value="{{ $post->titulo }}" class="form-control" placeholder="Título">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Descrição:</strong>
                        <textarea class="form-control" style="height:150px" name="descricao" placeholder="Descrição">{{ $post->descricao }}</textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Mensagem:</strong>
                        <textarea class="form-control" style="height:150px" name="mensagem" placeholder="Mensagem">{{ $post->mensagem }}</textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Imagem:</strong>
                        <input type="file" class="form-control"  name="imagem" placeholder="Imagem" />
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Link:</strong>
                        <input type="text" name="link" value="{{ $post->link }}" class="form-control" placeholder="https://www.seusite.com.br/link">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Whatsapp:</strong>
                        <input type="text" name="whatsapp" value="{{ $post->whatsapp }}" class="form-control" placeholder="(21) 99999-9999">
                    </div>
                </div>
                
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Tags:</strong>
                        <textarea class="form-control" style="height:150px" name="tags" placeholder="#tags">{{ $post->tags }}</textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Marcações:</strong>
                        <textarea class="form-control" style="height:150px" name="marcacoes" placeholder="@usuario">{{ $post->marcacoes }}</textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">Enviar</button>
                </div>
            </div>

        </form>
    </div>
</div>
@endsection