@extends('layouts.app')
@section('content')
<div class="row">
    <div class="col">

        <h1>Posts</h1>
        <a class="btn btn-info" href="{{ route('posts.create') }}">Novo</a>
    </div>
</div>
@include('posts.tabela',['posts'=>$posts])
@endsection