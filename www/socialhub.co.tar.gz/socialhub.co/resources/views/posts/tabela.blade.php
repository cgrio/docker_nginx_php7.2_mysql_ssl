@if (isset($posts) && !empty($posts))
@foreach($posts as $post)
<div class="row mb-1">
    <div class="col-3">{{$post->titulo}}</div>
    <div class="col-3">{{$post->descricao}}</div>
    <div class="col-2">{{$post->getTipoTexto()}}</div>
    <div class="col-2">{{$post->provedor}}</div>

    <div class="col-2">
    <a class="btn btn-info" href="{{ route('posts.show',$post->id) }}">Ver</a>

<a class="btn btn-primary" href="{{ route('posts.edit',$post->id) }}">Editar</a>

    <form action="{{ route('posts.destroy',$post->id) }}" method="POST">
@csrf
@method('DELETE')

<button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja apagar?')">Apagar</button>
</form>
    </div>
</div>
@endforeach
@endif