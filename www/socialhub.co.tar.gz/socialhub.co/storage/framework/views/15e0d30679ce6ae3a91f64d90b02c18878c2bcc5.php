<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb  px-5 py-3">
            <div class="float-left">
                <h2> Grupo</h2>
            </div>
            <div class="float-right">
                <a class="btn btn-primary" href="<?php echo e(route('grupos.index')); ?>"> Voltar</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 px-5 py-3">
            <p>
                <strong>Nome:</strong>
                <?php echo e($grupo->nome); ?>

</p>
      <p>
                <strong>Descrição:</strong>
                <?php echo e($grupo->descricao); ?>

</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/socialhub.co/resources/views/grupos/show.blade.php ENDPATH**/ ?>