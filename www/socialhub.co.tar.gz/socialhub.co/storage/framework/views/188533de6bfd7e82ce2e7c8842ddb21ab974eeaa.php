<?php if(isset($contas) && !empty($contas)): ?>
<?php $__currentLoopData = $contas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row mb-1">
    <div class="col-3"><?php echo e($conta->nome); ?></div>
    <div class="col-3"><?php echo e($conta->descricao); ?></div>
    <div class="col-2"><?php echo e($conta->getTipoTexto()); ?></div>
    <div class="col-2"><?php echo e($conta->provedor); ?></div>

    <div class="col-2">
    <form action="<?php echo e(route('contassociais.destroy',$conta->id)); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>

<button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja apagar?')">Apagar</button>
</form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /usr/share/nginx/html/socialhub.co/resources/views/contassociais/tabela.blade.php ENDPATH**/ ?>