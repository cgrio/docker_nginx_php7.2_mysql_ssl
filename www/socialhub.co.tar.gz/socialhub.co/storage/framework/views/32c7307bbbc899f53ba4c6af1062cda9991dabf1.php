
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('contassociais.index')); ?>"><?php echo e(__('Contas Sociais')); ?></a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('grupos.index')); ?>"><?php echo e(__('Grupos Sociais')); ?></a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('posts.index')); ?>"><?php echo e(__('Posts')); ?></a>
                            </li><?php /**PATH /usr/share/nginx/html/socialhub.co/resources/views/layouts/menu.blade.php ENDPATH**/ ?>