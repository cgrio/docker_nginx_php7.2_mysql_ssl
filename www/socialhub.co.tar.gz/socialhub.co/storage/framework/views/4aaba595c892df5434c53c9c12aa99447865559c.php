<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col">

        <h1>Posts</h1>
        <a class="btn btn-info" href="<?php echo e(route('posts.create')); ?>">Novo</a>
    </div>
</div>
<?php echo $__env->make('posts.tabela',['posts'=>$posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/socialhub.co/resources/views/posts/index.blade.php ENDPATH**/ ?>