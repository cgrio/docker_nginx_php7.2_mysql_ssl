<div class="row">
    <div class="col-lg-12 py-2 px-5">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <p>  <strong>Ops!</strong> Algumas informações precisam da sua atenção.</p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 py-2 px-5">
        <form action="<?php echo e(route('posts.update',$post->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Título:</strong>
                        <input type="text" name="titulo" value="<?php echo e($post->titulo); ?>" class="form-control" placeholder="Título">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Descrição:</strong>
                        <textarea class="form-control" style="height:150px" name="descricao" placeholder="Descrição"><?php echo e($post->descricao); ?></textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Mensagem:</strong>
                        <textarea class="form-control" style="height:150px" name="mensagem" placeholder="Mensagem"><?php echo e($post->mensagem); ?></textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">Enviar</button>
                </div>
            </div>

        </form>
    </div>
</div><?php /**PATH /usr/share/nginx/html/socialhub.co/resources/views/posts/form.blade.php ENDPATH**/ ?>