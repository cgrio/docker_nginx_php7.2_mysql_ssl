<?php if(isset($posts) && !empty($posts)): ?>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row mb-1">
    <div class="col-3"><?php echo e($post->titulo); ?></div>
    <div class="col-3"><?php echo e($post->descricao); ?></div>
    <div class="col-2"><?php echo e($post->getTipoTexto()); ?></div>
    <div class="col-2"><?php echo e($post->provedor); ?></div>

    <div class="col-2">
    <a class="btn btn-info" href="<?php echo e(route('posts.show',$post->id)); ?>">Ver</a>

<a class="btn btn-primary" href="<?php echo e(route('posts.edit',$post->id)); ?>">Editar</a>

    <form action="<?php echo e(route('posts.destroy',$post->id)); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>

<button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja apagar?')">Apagar</button>
</form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /usr/share/nginx/html/socialhub.co/resources/views/posts/tabela.blade.php ENDPATH**/ ?>