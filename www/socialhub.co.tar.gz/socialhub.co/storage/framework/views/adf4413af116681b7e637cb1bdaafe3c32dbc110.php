<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 px-5 py-2">
        <div class="float-left">
            <h2>Novo Grupo</h2>
        </div>
        <div class="float-right">
            <a class="btn btn-primary" href="<?php echo e(route('grupos.index')); ?>"> Voltar</a>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 px-5 py-2">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Ops!</strong> Algumas informações precisam da sua atenção.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 px-5 py-2">
        <form action="<?php echo e(route('grupos.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Nome:</strong>
                        <input type="text" name="nome" class="form-control" placeholder="Nome">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Descrição:</strong>
                        <textarea class="form-control" style="height:150px" name="descricao" placeholder="Descrição"></textarea>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">Enviar</button>
                </div>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/socialhub.co/resources/views/grupos/create.blade.php ENDPATH**/ ?>