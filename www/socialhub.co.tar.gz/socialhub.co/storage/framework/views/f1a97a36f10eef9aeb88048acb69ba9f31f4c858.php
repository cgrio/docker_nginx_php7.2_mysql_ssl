<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col">
            <h1>Gerenciar Grupo</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 px-5 py-3">
            <p>
                <strong>Nome:</strong>
                <?php echo e($grupo->nome); ?>

            </p>
            <p>
                <strong>Descrição:</strong>
                <?php echo e($grupo->descricao); ?>

            </p>
        </div>
    </div>
    <div class="row">
        <div class="col">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <p>  <strong>Ops!</strong> Algumas informações precisam da sua atenção.</p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        </div>
    </div>
    <div class="row">

            <div class="col">
                <a href="/auth/redirect/facebook/<?php echo e($grupo->id); ?>"><i class="h3 fab fa-facebook-f"></i>Facebook</a>
                <a href="/auth/redirect/twitter/<?php echo e($grupo->id); ?>"><i class="h3 fab fa-twitter-f"></i>Twitter</a>
                <a href="/auth/redirect/linkedin/<?php echo e($grupo->id); ?>"><i class="h3 fab fa-linkedin-f"></i>Linkedin</a>
                <a href="/auth/redirect/instagram/<?php echo e($grupo->id); ?>"><i class="h3 fab fa-instagram-f"></i>Instagram</a>
                <a href="/auth/redirect/pinterest/<?php echo e($grupo->id); ?>"><i class="h3 fab fa-pinterest-f"></i>Pinterest</a>
            </div>
    </div>
    
    <?php echo $__env->make('contassociais.tabela',['contas' => $contas], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/socialhub.co/resources/views/grupos/gerenciar.blade.php ENDPATH**/ ?>