<?php $__env->startSection('content'); ?>


<div class="row">
        <div class="col-lg-12 px-5 py-3">
            <div class="float-left">
                <h2>Grupos</h2>
            </div>
            <div class="float-right">
                <a class="btn btn-success" href="<?php echo e(route('grupos.create')); ?>"> Novo Grupo</a>
            </div>
        </div>
    </div>


    <div class="row">
<div class="col-12 px-5 py-3">

<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


</div>

</div>




<div class="row">
<div class="col-12 px-5">



    <table class="table table-bordered">
        <tr>
            <th>id</th>
            <th>Nome</th>
            <th>Descrição</th>
            <th width="350px">Ações</th>
        </tr>
     <?php if(!empty($grupos)): ?>
        <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($grupo->nome); ?></td>
            <td><?php echo e($grupo->descricao); ?></td>
            <td>
                <form action="<?php echo e(route('grupos.destroy',$grupo->id)); ?>" method="POST">

                    <a class="btn btn-info" href="<?php echo e(route('grupos.show',$grupo->id)); ?>">Ver</a>

                    <a class="btn btn-primary" href="<?php echo e(route('grupos.edit',$grupo->id)); ?>">Editar</a>

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja apagar?')">Apagar</button>
                    <a class="btn btn-success" href="/grupos/<?php echo e($grupo->id); ?>/gerenciar">Gerenciar</a>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>

    <?php echo $grupos->links(); ?>





</div>

</div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/socialhub.co/resources/views/grupos/index.blade.php ENDPATH**/ ?>